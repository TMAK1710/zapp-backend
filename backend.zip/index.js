"use strict";

const express = require("express");
const cors = require("cors");
const admin = require("firebase-admin");

// node-fetch v2 (CommonJS)
const fetch = require("node-fetch");

// ======================
// 0) Basic config
// ======================
const PORT = process.env.PORT || 8080;

// 允许的前端来源（可选）
// 例：CORS_ALLOW_ORIGIN=https://xxx.zapp.page,https://yyy.zapp.page
const CORS_ALLOW_ORIGIN = process.env.CORS_ALLOW_ORIGIN || "*";

// Firebase Web API Key (必须：放到 Cloud Run env vars)
const FIREBASE_WEB_API_KEY = process.env.FIREBASE_WEB_API_KEY || "";

// ======================
// 1) Firebase Admin init (Cloud Run / Local)
// ======================
// ✅ Cloud Run：推荐用 Application Default Credentials（不需要 serviceAccountKey.json）
// 你只要在 Cloud Run 选择一个有 Firestore/Auth 权限的 service account 即可。
if (!admin.apps.length) {
  admin.initializeApp();
}

const db = admin.firestore();

// ======================
// 2) Express + CORS
// ======================
const app = express();
app.use(express.json());

app.use(
  cors({
    origin: CORS_ALLOW_ORIGIN === "*" ? true : CORS_ALLOW_ORIGIN.split(","),
    credentials: true,
  })
);

// ======================
// 3) Helpers - Firebase Auth REST
// ======================
function assertApiKey() {
  if (!FIREBASE_WEB_API_KEY) {
    throw new Error(
      "Missing FIREBASE_WEB_API_KEY. Set it as Cloud Run env var."
    );
  }
}

async function firebaseSignUp(email, password) {
  assertApiKey();

  const url = `https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=${FIREBASE_WEB_API_KEY}`;
  const r = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password, returnSecureToken: true }),
  });

  const data = await r.json();
  if (!r.ok) {
    const err = new Error("FIREBASE_SIGNUP_FAILED");
    err.detail = data;
    throw err;
  }
  return data;
}

async function firebaseSignIn(email, password) {
  assertApiKey();

  const url = `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${FIREBASE_WEB_API_KEY}`;
  const r = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password, returnSecureToken: true }),
  });

  const data = await r.json();
  if (!r.ok) {
    const err = new Error("FIREBASE_LOGIN_FAILED");
    err.detail = data;
    throw err;
  }
  return data;
}

// ======================
// 4) Auth middleware
// ======================
async function requireAuth(req, res, next) {
  try {
    const auth = req.headers.authorization || "";
    if (!auth.startsWith("Bearer ")) {
      return res.status(401).json({
        success: false,
        message: "Missing or invalid Authorization header",
      });
    }

    const idToken = auth.substring("Bearer ".length).trim();
    const decoded = await admin.auth().verifyIdToken(idToken);

    req.user = {
      uid: decoded.uid,
      email: decoded.email || null,
    };

    next();
  } catch (e) {
    return res.status(401).json({
      success: false,
      message: "BAD_TOKEN",
      detail: String(e),
    });
  }
}

// ======================
// 5) Routes
// ======================
app.get("/health", (req, res) => {
  res.json({
    ok: true,
    message: "Backend is running",
    time: new Date().toISOString(),
  });
});

// ---------- Auth ----------
app.post("/auth/register", async (req, res) => {
  try {
    const { email, password } = req.body || {};
    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: "email/password required",
      });
    }

    const data = await firebaseSignUp(email, password);
    return res.json({ success: true, uid: data.localId, email: data.email });
  } catch (e) {
    return res.status(400).json({
      success: false,
      message: "REGISTER_FAILED",
      detail: e.detail || String(e),
    });
  }
});

app.post("/auth/login", async (req, res) => {
  try {
    const { email, password } = req.body || {};
    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: "email/password required",
      });
    }

    const data = await firebaseSignIn(email, password);

    return res.json({
      success: true,
      idToken: data.idToken,
      refreshToken: data.refreshToken,
      expiresIn: data.expiresIn,
      email: data.email,
    });
  } catch (e) {
    return res.status(400).json({
      success: false,
      message: "LOGIN_FAILED",
      detail: e.detail || String(e),
    });
  }
});

// ---------- Protected ----------
app.get("/me", requireAuth, (req, res) => {
  res.json({
    success: true,
    uid: req.user.uid,
    email: req.user.email,
  });
});

// ======================
// 6) Orders (Firestore)
// Path: users/{uid}/orders/{orderId}
// ======================
function calcTotal(items) {
  return items.reduce((sum, it) => sum + (Number(it.qty) || 0) * (Number(it.price) || 0), 0);
}

// GET /orders
app.get("/orders", requireAuth, async (req, res) => {
  try {
    const ref = db
      .collection("users")
      .doc(req.user.uid)
      .collection("orders")
      .orderBy("createdAt", "desc");

    const snap = await ref.get();

    const orders = snap.docs.map((d) => {
      const data = d.data();
      return {
        id: d.id,
        status: data.status || "PLACED",
        total: data.total || 0,
        items: data.items || [],
        createdAt: data.createdAt ? data.createdAt.toDate().toISOString() : null,
      };
    });

    return res.json({ success: true, orders });
  } catch (e) {
    return res.status(500).json({
      success: false,
      message: "ORDERS_FETCH_FAILED",
      detail: String(e),
    });
  }
});

// POST /orders  (✅支持“用户选择物品+数量”的下单)
// body:
// {
//   "items": [
//     {"name":"Cappuccino","qty":2,"price":4.5},
//     {"name":"Club Sandwich","qty":1,"price":6.0}
//   ]
// }
app.post("/orders", requireAuth, async (req, res) => {
  try {
    const items = Array.isArray(req.body?.items) ? req.body.items : [];
    if (items.length === 0) {
      return res.status(400).json({
        success: false,
        message: "items required",
      });
    }

    const total = calcTotal(items);

    const docRef = db
      .collection("users")
      .doc(req.user.uid)
      .collection("orders")
      .doc();

    await docRef.set({
      status: "PLACED",
      total,
      items,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    return res.json({
      success: true,
      order: {
        id: docRef.id,
        status: "PLACED",
        total,
        items,
      },
    });
  } catch (e) {
    return res.status(500).json({
      success: false,
      message: "ORDER_CREATE_FAILED",
      detail: String(e),
    });
  }
});

// POST /orders/:id/cancel
app.post("/orders/:id/cancel", requireAuth, async (req, res) => {
  try {
    const orderId = req.params.id;

    const docRef = db
      .collection("users")
      .doc(req.user.uid)
      .collection("orders")
      .doc(orderId);

    const snap = await docRef.get();
    if (!snap.exists) {
      return res.status(404).json({ success: false, message: "ORDER_NOT_FOUND" });
    }

    await docRef.update({
      status: "CANCELLED",
      cancelledAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    return res.json({ success: true, id: orderId, status: "CANCELLED" });
  } catch (e) {
    return res.status(500).json({
      success: false,
      message: "ORDER_CANCEL_FAILED",
      detail: String(e),
    });
  }
});

// ======================
app.listen(PORT, () => {
  console.log(`Backend running on port ${PORT}`);
  console.log("FIREBASE_WEB_API_KEY exists?", !!FIREBASE_WEB_API_KEY);
});
